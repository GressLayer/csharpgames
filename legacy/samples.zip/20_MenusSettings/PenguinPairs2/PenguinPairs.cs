using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

class PenguinPairs : Game
{
    protected GraphicsDeviceManager graphics;
    protected SpriteBatch spriteBatch;
    protected Matrix spriteScale;
    protected InputHelper inputHelper;
    protected static Point screen;
    protected Point windowSize;

    protected static Random random;
    protected static AssetManager assetManager;
    protected static GameSettingsManager gameSettingsManager;

    protected GameObjectList gameWorld;
    protected OnOffButton onOffButton;
    protected Slider musicVolumeSlider;

    [STAThread]
    static void Main()
    {
        PenguinPairs game = new PenguinPairs();
        game.Run();
    }

    public PenguinPairs()
    {
        Content.RootDirectory = "Content";
        graphics = new GraphicsDeviceManager(this);
        IsMouseVisible = true;
        inputHelper = new InputHelper();
        random = new Random();
        assetManager = new AssetManager(Content);
        gameSettingsManager = new GameSettingsManager();
    }

    public bool FullScreen
    {
        get { return graphics.IsFullScreen; }
        set
        {
            ApplyResolutionSettings(value);
        }
    }

    public void ApplyResolutionSettings(bool fullScreen = false)
    {
        if (!fullScreen)
        {
            graphics.PreferredBackBufferWidth = windowSize.X;
            graphics.PreferredBackBufferHeight = windowSize.Y;
            graphics.IsFullScreen = false;
            graphics.ApplyChanges();
        }
        else
        {
            graphics.PreferredBackBufferWidth = GraphicsAdapter.DefaultAdapter.CurrentDisplayMode.Width;
            graphics.PreferredBackBufferHeight = GraphicsAdapter.DefaultAdapter.CurrentDisplayMode.Height;
            graphics.IsFullScreen = true;
            graphics.ApplyChanges();
        }

        float targetAspectRatio = (float)screen.X / (float)screen.Y;
        int width = graphics.PreferredBackBufferWidth;
        int height = (int)(width / targetAspectRatio);
        if (height > graphics.PreferredBackBufferHeight)
        {
            height = graphics.PreferredBackBufferHeight;
            width = (int)(height * targetAspectRatio);
        }

        Viewport viewport = new Viewport();
        viewport.X = (graphics.PreferredBackBufferWidth / 2) - (width / 2);
        viewport.Y = (graphics.PreferredBackBufferHeight / 2) - (height / 2);
        viewport.Width = width;
        viewport.Height = height;
        GraphicsDevice.Viewport = viewport;

        inputHelper.Scale = new Vector2((float)GraphicsDevice.Viewport.Width / screen.X,
                                        (float)GraphicsDevice.Viewport.Height / screen.Y);
        inputHelper.Offset = new Vector2(viewport.X, viewport.Y);
        spriteScale = Matrix.CreateScale(inputHelper.Scale.X, inputHelper.Scale.Y, 1);
    }

    protected override void LoadContent()
    {
        screen = new Point(1200, 900);
        windowSize = new Point(1024, 768);
        FullScreen = false;

        spriteBatch = new SpriteBatch(GraphicsDevice);

        gameWorld = new GameObjectList();

        // add a background
        SpriteGameObject background = new SpriteGameObject("Sprites/spr_background_options", 0, "background");
        gameWorld.Add(background);

        // add an on/off button with a text description
        TextGameObject onofftext = new TextGameObject("Fonts/MenuFont", 1);
        onofftext.Text = "Hints";
        onofftext.Position = new Vector2(150, 340);
        onofftext.Color = Color.DarkBlue;
        gameWorld.Add(onofftext);

        onOffButton = new OnOffButton("Sprites/spr_button_offon@2");
        onOffButton.Position = new Vector2(650, 340);
        gameWorld.Add(onOffButton);

        // add a slider to control the background music volume
        TextGameObject bgmusictext = new TextGameObject("Fonts/MenuFont", 1);
        bgmusictext.Text = "Music volume";
        bgmusictext.Color = Color.DarkBlue;
        bgmusictext.Position = new Vector2(150, 480);
        gameWorld.Add(bgmusictext);

        musicVolumeSlider = new Slider("Sprites/spr_slider_bar", "Sprites/spr_slider_button", 1);
        musicVolumeSlider.Position = new Vector2(650, 500);
        gameWorld.Add(musicVolumeSlider);
        musicVolumeSlider.Value = MediaPlayer.Volume;

        assetManager.PlayMusic("Sounds/snd_music");
    }

    protected void HandleInput()
    {
        inputHelper.Update();
        if (inputHelper.KeyPressed(Keys.Escape))
        {
            Exit();
        }
        if (inputHelper.KeyPressed(Keys.F5))
        {
            FullScreen = !FullScreen;
        }
        gameWorld.HandleInput(inputHelper);
    }

    protected override void Update(GameTime gameTime)
    {
        HandleInput();
        gameWorld.Update(gameTime);
        MediaPlayer.Volume = musicVolumeSlider.Value;
        if (onOffButton.On)
        {
            GameSettingsManager.SetValue("hints", "on");
        }
        else
        {
            GameSettingsManager.SetValue("hints", "off");
        }
    }

    protected override void Draw(GameTime gameTime)
    {
        GraphicsDevice.Clear(Color.Black);
        spriteBatch.Begin(SpriteSortMode.Deferred, null, null, null, null, null, spriteScale);
        gameWorld.Draw(gameTime, spriteBatch);
        spriteBatch.End();
    }

    public static Random Random
    {
        get { return random; }
    }

    public static AssetManager AssetManager
    {
        get { return assetManager; }
    }

    public static GameSettingsManager GameSettingsManager
    {
        get { return gameSettingsManager; }
    }

    public static Point Screen
    {
        get { return screen; }
        set { screen = value; }
    }
}