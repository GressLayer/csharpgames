﻿using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

class GlitterField : GameObject
{
    protected List<Vector2> positions;
    protected List<float> scales;
    protected int width, height, xOffset;
    protected Texture2D glitter;
    protected Texture2D target;

    public GlitterField(Texture2D target, int density, int width, int height, int xOffset = 0, int layer = 0, string id = "")
        : base(layer, id)
    {
        glitter = JewelJam.AssetManager.GetSprite("spr_glitter");
        this.target = target;
        this.xOffset = xOffset;

        this.width = width;
        this.height = height;
        positions = new List<Vector2>();
        scales = new List<float>();

        for (int i = 0; i < density; i++)
        {
            positions.Add(CreateRandomPosition());
            scales.Add(0f);
        }
    }

    public Vector2 CreateRandomPosition()
    {
        Vector2 randomPos = Vector2.Zero;
        while (true)
        {
            randomPos = new Vector2(JewelJam.Random.Next(width), JewelJam.Random.Next(height));
            if (target == null)
            {
                break;
            }
            Rectangle sourceRectangle = new Rectangle((int)randomPos.X + xOffset, (int)randomPos.Y, 1, 1);
            Color[] retrievedColor = new Color[1];
            target.GetData<Color>(0, sourceRectangle, retrievedColor, 0, 1);
            if (retrievedColor[0].A == 255)
            {
                break;
            }
        }
        return randomPos;
    }

    public override void Update(GameTime gameTime)
    {
        for (int i = 0; i < scales.Count; i++)
        {
            if (scales[i] == 0 && JewelJam.Random.NextDouble() < 0.001)
            {
                scales[i] += 0.05f;
            }
            else if (scales[i] != 0)
            {
                scales[i] += 0.05f;
                if (scales[i] >= 2.0f)
                {
                    scales[i] = 0f;
                    positions[i] = CreateRandomPosition();
                }
            }
        }
    }

    public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
        Vector2 glitterCenter = new Vector2(glitter.Width, glitter.Height) / 2;
        for (int i = 0; i < scales.Count; i++)
        {
            float scale = scales[i];
            if (scales[i] > 1)
            {
                scale = 2 - scales[i];
            }
            spriteBatch.Draw(glitter, GlobalPosition + positions[i], null, Color.White, 0f, glitterCenter, scale, SpriteEffects.None, 0);
        }
    }
}
