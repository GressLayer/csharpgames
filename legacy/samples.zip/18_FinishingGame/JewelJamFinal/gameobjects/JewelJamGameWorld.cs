﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

class JewelJamGameWorld : GameObjectList
{
    protected Button helpButton;
    protected SpriteGameObject helpFrame;
    protected SpriteGameObject title;
    protected SpriteGameObject gameOver;

    public JewelJamGameWorld()
    {
        title = new SpriteGameObject("spr_title", 100);
        Add(title);
        Add(new SpriteGameObject("spr_background"));

        SpriteGameObject scoreFrame = new SpriteGameObject("spr_scoreframe", 1);
        scoreFrame.Position = new Vector2(20, 20);
        Add(scoreFrame);

        ScoreGameObject score = new ScoreGameObject(2, "score");
        score.Position = new Vector2(270, 80);
        Add(score);

        // help button
        helpButton = new Button("spr_button_help", 2, "help_button");
        helpButton.Position = new Vector2(1268, 20);
        Add(helpButton);

        // help frame
        helpFrame = new SpriteGameObject("spr_frame_help", 2, "help_frame");
        helpFrame.Position = new Vector2(636, 120);
        helpFrame.Visible = false;
        Add(helpFrame);

        JewelCart jewelCart = new JewelCart(1, "jewelcart");
        jewelCart.Position = new Vector2(410, 230);
        jewelCart.MinXPos = 410;
        Add(jewelCart);

        GameObjectList playingField = new GameObjectList(1, "playingfield");
        playingField.Position = new Vector2(85, 150);
        Add(playingField);

        JewelGrid grid = new JewelGrid(10, 5, 0, "grid");
        playingField.Add(grid);

        playingField.Add(new RowSelectGameObject(1));

        gameOver = new SpriteGameObject("spr_gameover", 100, "gameover");
        gameOver.Visible = false;
        gameOver.Position = new Vector2(1440, 1080)/2 - gameOver.Center;
        Add(gameOver);

        SpriteGameObject doubleOverlay = new SpriteGameObject("spr_double", 1);
        doubleOverlay.Position = new Vector2(800, 400);
        VisibilityTimer doubleTimer = new VisibilityTimer(doubleOverlay, 0, "doubleTimer");
        Add(doubleOverlay);
        Add(doubleTimer);

        SpriteGameObject tripleOverlay = new SpriteGameObject("spr_triple", 1);
        tripleOverlay.Position = new Vector2(800, 400);
        VisibilityTimer tripleTimer = new VisibilityTimer(tripleOverlay, 0, "tripleTimer");
        Add(tripleOverlay);
        Add(tripleTimer);
    }

    public override void HandleInput(InputHelper inputHelper)
    {
        if (title.Visible)
        {
            if (inputHelper.KeyPressed(Keys.Space))
            {
                title.Visible = false;
            }
        }
        else if (GameOver)
        {
            if (inputHelper.KeyPressed(Keys.Space))
            {
                Reset();
            }
        }
        else
        {
            base.HandleInput(inputHelper);
            if (helpButton.Pressed || (helpFrame.Visible && inputHelper.KeyPressed(Keys.Space)))
            {
                helpFrame.Visible = !helpFrame.Visible;
            }
        }

    }

    public override void Update(GameTime gameTime)
    {
        if (GameOver && !gameOver.Visible)
        {
            gameOver.Visible = true;
            JewelJam.AssetManager.PlaySound("snd_gameover");
        }
        else if (!helpFrame.Visible && !title.Visible)
        {
            base.Update(gameTime);
        }
    }

    public override void Reset()
    {
        base.Reset();
        title.Visible = false;
        helpFrame.Visible = false;
        gameOver.Visible = false;
    }

    public bool GameOver
    {
        get
        {
            JewelCart jewelCart = Find("jewelcart") as JewelCart;
            return (jewelCart.Position.X > JewelJam.Screen.X);
        }
    }
}