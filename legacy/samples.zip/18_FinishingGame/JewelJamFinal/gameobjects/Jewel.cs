﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

class Jewel : SpriteGameObject
{
    protected int variation;
    protected GlitterField glitters;

    public Jewel(int layer = 0) : base("spr_jewels", layer)
    {
        variation = JewelJam.Random.Next(27);
        glitters = new GlitterField(sprite, 2, sprite.Height, sprite.Height, variation * sprite.Height);
        glitters.Parent = this;
    }

    public override void Update(GameTime gameTime)
    {
        GameObjectGrid parent = Parent as GameObjectGrid;
        Vector2 anchorPosition = parent.GetAnchorPosition(this);
        velocity = (anchorPosition - position) * 8;
        glitters.Update(gameTime);
        base.Update(gameTime);
    }

    public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
        if (!visible)
        {
            return;
        }
        Rectangle source = new Rectangle(variation * sprite.Height, 0, sprite.Height, sprite.Height);
        spriteBatch.Draw(sprite, GlobalPosition, source, Color.White);
        glitters.Draw(gameTime, spriteBatch);
    }

    public int Variation
    {
        get { return variation; }
    }
}
