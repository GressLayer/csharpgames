﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

class JewelCart : SpriteGameObject
{
    protected float push;
    protected float minXPos;
    protected GlitterField glitters;

    public JewelCart(int layer = 0, string id = "")
        : base("spr_jewelcart", layer, id)
    {
        velocity.X = 6;
        push = 50;
        glitters = new GlitterField(null, 40, 435, 75);
        glitters.Position = new Vector2(275, 475);
        glitters.Parent = this;
    }

    public override void Update(GameTime gameTime)
    {
        push = MathHelper.Max(push - 0.00001f, 1);
        glitters.Update(gameTime); 
        base.Update(gameTime);
    }

    public override void Reset()
    {
        base.Reset();
        position.X = minXPos;
        velocity.X = 6;
    }

    public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
        base.Draw(gameTime, spriteBatch);
        glitters.Draw(gameTime, spriteBatch);
    }

    public void Push()
    {
        position.X = MathHelper.Max(position.X - push, minXPos);
    }

    public float MinXPos
    {
        get { return minXPos; }
        set { minXPos = value; }
    }
}

