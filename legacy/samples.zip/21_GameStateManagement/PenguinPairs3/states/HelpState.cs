﻿using Microsoft.Xna.Framework;

class HelpState : GameObjectList
{
    protected Button backButton;

    public HelpState()
    {
        // add a background
        SpriteGameObject background = new SpriteGameObject("Sprites/spr_background_help", 0, "background");
        Add(background);

        // add a back button
        backButton = new Button("Sprites/spr_button_back", 1);
        backButton.Position = new Vector2(415, 720);
        Add(backButton);
    }

    public override void HandleInput(InputHelper inputHelper)
    {
        base.HandleInput(inputHelper);
        if (backButton.Pressed)
        {
            PenguinPairs.GameStateManager.SwitchTo("titleMenu");
        }
    }
}