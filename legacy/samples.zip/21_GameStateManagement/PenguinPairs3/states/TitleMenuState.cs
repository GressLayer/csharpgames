﻿using Microsoft.Xna.Framework;

class TitleMenuState : GameObjectList
{
    protected Button playButton, optionButton, helpButton;

    public TitleMenuState()
    {
        // load the title screen
        SpriteGameObject titleScreen = new SpriteGameObject("Sprites/spr_titlescreen", 0, "background");
        Add(titleScreen);

        // add a play button
        playButton = new Button("Sprites/spr_button_play", 1);
        playButton.Position = new Vector2(415, 540);
        Add(playButton);

        // add an options button
        optionButton = new Button("Sprites/spr_button_options", 1);
        optionButton.Position = new Vector2(415, 650);
        Add(optionButton);

        // add a help button
        helpButton = new Button("Sprites/spr_button_help", 1);
        helpButton.Position = new Vector2(415, 760);
        Add(helpButton);
    }

    public override void HandleInput(InputHelper inputHelper)
    {
        base.HandleInput(inputHelper);
        if (playButton.Pressed)
        {
            PenguinPairs.GameStateManager.SwitchTo("levelMenu");
        }
        else if (optionButton.Pressed)
        {
            PenguinPairs.GameStateManager.SwitchTo("optionsMenu");
        }
        else if (helpButton.Pressed)
        {
            PenguinPairs.GameStateManager.SwitchTo("helpState");
        }
    }
}