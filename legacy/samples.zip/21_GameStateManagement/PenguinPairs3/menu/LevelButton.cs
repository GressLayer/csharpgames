﻿using Microsoft.Xna.Framework;

class LevelButton : GameObjectList
{
    protected TextGameObject levelIndexText;
    protected SpriteGameObject levelsSolved, levelsUnsolved, sprLock;
    protected bool pressed;
    protected int levelIndex;
    
    public LevelButton(int levelIndex, int layer = 0, string id = "")
        : base(layer, id)
    {
        this.levelIndex = levelIndex;
        
        levelsSolved = new SpriteGameObject("Sprites/spr_levels_solved@6", 0, "", levelIndex - 1);
        levelsUnsolved = new SpriteGameObject("Sprites/spr_level_unsolved");
        sprLock = new SpriteGameObject("Sprites/spr_lock", 2);
        Add(levelsSolved);
        Add(levelsUnsolved);
        Add(sprLock);

        levelIndexText = new TextGameObject("Fonts/ScoreFont", 1);
        levelIndexText.Text = levelIndex.ToString();

        // calculate the text position
        levelIndexText.Position = new Vector2(levelsSolved.Width - levelIndexText.Size.X,
            levelsSolved.Height - levelIndexText.Size.Y + 45) / 2;
        levelIndexText.Color = Color.Black;
        Add(levelIndexText);
    }

    public override void HandleInput(InputHelper inputHelper)
    {
        pressed = inputHelper.MouseLeftButtonPressed() &&
            sprLock.BoundingBox.Contains((int)inputHelper.MousePosition.X, (int)inputHelper.MousePosition.Y);
    }

    public int LevelIndex
    {
        get { return levelIndex; }
    }

    public bool Pressed
    {
        get { return pressed; }
    }

    public int Width
    {
        get { return sprLock.Width; }
    }

    public int Height
    {
        get { return sprLock.Height; }
    }
}