﻿using Microsoft.Xna.Framework;

class AnimalSelector : GameObjectList
{
    protected Arrow arrowRight, arrowUp, arrowLeft, arrowDown;
    protected Animal selectedAnimal;

    public AnimalSelector(int layer = 0, string id = "")
        : base(layer, id)
    {
        // add the four arrows for both states
        arrowRight = new Arrow("Sprites/spr_arrow1@4", "Sprites/spr_arrow2@4", 0, "arrowright", 0);
        arrowRight.Position = new Vector2(arrowRight.Width, 0);
        arrowUp = new Arrow("Sprites/spr_arrow1@4", "Sprites/spr_arrow2@4", 0, "arrowup", 1);
        arrowUp.Position = new Vector2(0, -arrowUp.Height);
        arrowLeft = new Arrow("Sprites/spr_arrow1@4", "Sprites/spr_arrow2@4", 0, "arrowleft", 2);
        arrowLeft.Position = new Vector2(-arrowLeft.Width, 0);
        arrowDown = new Arrow("Sprites/spr_arrow1@4", "Sprites/spr_arrow2@4", 0, "arrowdown", 3);
        arrowDown.Position = new Vector2(0, arrowDown.Height);

        Add(arrowRight);
        Add(arrowUp);
        Add(arrowLeft);
        Add(arrowDown);
    }

    public override void HandleInput(InputHelper inputHelper)
    {
        if (!visible)
        {
            return;
        }

        base.HandleInput(inputHelper);
        Vector2 animalVelocity = Vector2.Zero;
        if (arrowDown.Pressed)
        {
            animalVelocity.Y = 1;
        }
        else if (arrowUp.Pressed)
        {
            animalVelocity.Y = -1;
        }
        else if (arrowLeft.Pressed)
        {
            animalVelocity.X = -1;
        }
        else if (arrowRight.Pressed)
        {
            animalVelocity.X = 1;
        }
        animalVelocity *= 300;
        if (inputHelper.MouseLeftButtonPressed())
        {
            visible = false;
        }
        if (selectedAnimal == null && animalVelocity == Vector2.Zero)
        {
            return;
        }
        selectedAnimal.Velocity = animalVelocity;
    }

    public override void Reset()
    {
        base.Reset();
        visible = false;
    }

    public Animal SelectedAnimal
    {
        get { return selectedAnimal; }
        set { selectedAnimal = value; }
    }
}