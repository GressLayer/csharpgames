﻿class Arrow : GameObjectList
{
    protected SpriteGameObject arrowNormal, arrowHover;
    protected bool pressed;

    public Arrow(string assetNameNormal, string assetNameHover, int layer = 0, string id = "", int stripIndex = 0)
        : base(layer, id)
    {
        arrowNormal = new SpriteGameObject(assetNameNormal, layer, id, stripIndex);
        arrowHover = new SpriteGameObject(assetNameHover, layer, id, stripIndex);
        Add(arrowNormal);
        Add(arrowHover);
        arrowHover.Visible = false;
        pressed = false;
    }

    public override void HandleInput(InputHelper inputHelper)
    {
        base.HandleInput(inputHelper);
        arrowHover.Visible = arrowNormal.BoundingBox.Contains((int)inputHelper.MousePosition.X, (int)inputHelper.MousePosition.Y);
        pressed = inputHelper.MouseLeftButtonPressed() && arrowHover.Visible;
    }

    public int Width
    {
        get { return arrowNormal.Width; }
    }

    public int Height
    {
        get { return arrowNormal.Height; }
    }

    public bool Pressed
    {
        get { return pressed; }
    }
}