﻿using Microsoft.Xna.Framework;

class JewelJamGameWorld : GameObjectList
{
    public JewelJamGameWorld()
    {
        Add(new SpriteGameObject("spr_background"));

        GameObjectList playingField = new GameObjectList(1);
        playingField.Position = new Vector2(85, 150);
        this.Add(playingField);

        JewelGrid grid = new JewelGrid(10, 5, 0);
        playingField.Add(grid);

        playingField.Add(new RowSelectGameObject(grid, 1));
    }
}