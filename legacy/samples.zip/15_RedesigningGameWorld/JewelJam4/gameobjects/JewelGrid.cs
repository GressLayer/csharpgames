﻿using Microsoft.Xna.Framework;

class JewelGrid : GameObjectGrid
{
    public JewelGrid(int rows, int columns, int layer = 0)
        : base(rows, columns, layer)
    {
        cellWidth = 85;
        cellHeight = 85;
        Reset();
    }

    public void ShiftRowRight(int selectedRow)
    {
        GameObject lastObj = grid[Columns - 1, selectedRow];
        for (int x = Columns - 1; x > 0; x--)
        {
            grid[x, selectedRow] = grid[x - 1, selectedRow];
        }
        grid[0, selectedRow] = lastObj;
        lastObj.Position = new Vector2(-cellWidth, selectedRow * cellHeight);
    }

    public void ShiftRowLeft(int selectedRow)
    {
        GameObject firstObj = grid[0, selectedRow];
        for (int x = 0; x < Columns - 1; x++)
        {
            grid[x, selectedRow] = grid[x + 1, selectedRow];
        }
        grid[Columns - 1, selectedRow] = firstObj;
        firstObj.Position = new Vector2(Columns * cellWidth, selectedRow * cellHeight);
    }

    public override void Reset()
    {
        ClearAll();
        for (int i = 0; i < Rows * Columns; i++)
        {
            Add(new Jewel());
        }
    }
}
