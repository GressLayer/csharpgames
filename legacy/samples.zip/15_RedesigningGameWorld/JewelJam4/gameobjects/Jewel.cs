﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

class Jewel : SpriteGameObject
{
    protected int variation;

    public Jewel(int layer = 0) : base("spr_jewels", layer)
    {
        variation = JewelJam.Random.Next(27);
    }

    public override void Update(GameTime gameTime)
    {
        GameObjectGrid parent = Parent as GameObjectGrid;
        Vector2 anchorPosition = parent.GetAnchorPosition(this);
        velocity = (anchorPosition - position) * 8;
        base.Update(gameTime);
    }

    public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
        if (!visible)
        {
            return;
        }
        Rectangle source = new Rectangle(variation * sprite.Height, 0, sprite.Height, sprite.Height);
        spriteBatch.Draw(sprite, GlobalPosition, source, Color.White);
    }

    public int Variation
    {
        get { return variation; }
    }
}