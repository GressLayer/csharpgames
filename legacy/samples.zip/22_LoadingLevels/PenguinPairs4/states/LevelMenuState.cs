﻿using System.Collections.Generic;
using Microsoft.Xna.Framework;

class LevelMenuState : GameObjectList
{
    protected Button backButton;

    public LevelMenuState()
    {
        PlayingState playingState = PenguinPairs.GameStateManager.GetGameState("playingState") as PlayingState;
        List<Level> levels = playingState.Levels;

        // add a background
        SpriteGameObject background = new SpriteGameObject("Sprites/spr_background_levelselect", 0, "background");
        Add(background);

        // add the level buttons
        for (int i = 0; i < levels.Count; i++)
        {
            int row = i / 5;
            int column = i % 5;
            LevelButton level = new LevelButton(i + 1, levels[i], 1);
            level.Position = new Vector2(column * (level.Width + 30), row * (level.Height + 5)) + new Vector2(155, 230);
            Add(level);
        }

        // add a back button
        backButton = new Button("Sprites/spr_button_back", 1);
        backButton.Position = new Vector2(415, 720);
        Add(backButton);
    }

    public int LevelSelected
    {
        get
        {
            foreach (GameObject obj in children)
            {
                LevelButton levelButton = obj as LevelButton;
                if (levelButton != null && levelButton.Pressed)
                {
                    return levelButton.LevelIndex;
                }
            }
            return -1;
        }
    }

    public override void HandleInput(InputHelper inputHelper)
    {
        base.HandleInput(inputHelper);

        if (LevelSelected != -1)
        {
            PlayingState playingState = PenguinPairs.GameStateManager.GetGameState("playingState") as PlayingState;
            playingState.CurrentLevelIndex = LevelSelected - 1;
            PenguinPairs.GameStateManager.SwitchTo("playingState");
        }
        else if (backButton.Pressed)
        {
            PenguinPairs.GameStateManager.SwitchTo("titleMenu");
        }
    }
}