﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

enum TileType { Normal, Background, Wall };

class Tile : SpriteGameObject
{
    protected TileType type;

    public Tile(string assetname, int layer = 0, string id = "", int sheetIndex = 0)
        : base(assetname, layer, id, sheetIndex)
    {
        type = TileType.Normal;
    }

    public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
        if (type == TileType.Background)
        {
            return;
        }
        base.Draw(gameTime, spriteBatch);
    }

    public TileType TileType
    {
        get { return type; }
        set { type = value; }
    }
}