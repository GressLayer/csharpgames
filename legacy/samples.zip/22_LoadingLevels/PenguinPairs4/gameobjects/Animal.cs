﻿using Microsoft.Xna.Framework;
using System;

class Animal : SpriteGameObject
{
    protected Vector2 initialPosition;
    protected bool initialEmptyBox;
    protected bool boxed;

    public Animal(string assetname, int layer = 0, string id = "", char color = 'r')
        : base(assetname, layer, id, 8)
    {
        boxed = char.IsUpper(color);
        initialEmptyBox = boxed && char.ToLower(color) == 'x';
        string animals = "brgyopmx";
        sprite.SheetIndex = animals.IndexOf(char.ToLower(color));
    }

    public override void Reset()
    {
        base.Reset();
        position = initialPosition;
        velocity = Vector2.Zero;
        if (initialEmptyBox)
        {
            sprite.SheetIndex = 7;
        }
    }

    public bool IsSeal()
    {
        return sprite.SheetIndex == 7 && !boxed;
    }

    public bool IsMultiColoredPenguin()
    {
        return sprite.SheetIndex == 6 && !boxed;
    }

    public bool IsEmptyBox()
    {
        return sprite.SheetIndex == 7 && boxed;
    }

    public Vector2 InitialPosition
    {
        set { initialPosition = value; }
    }
}