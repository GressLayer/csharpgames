﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

class Jewel : SpriteGameObject
{
    public Jewel(Texture2D spr, int layer = 0)
        : base(spr, layer)
    {
    }

    public override void Update(GameTime gameTime)
    {
        GameObjectGrid parent = Parent as GameObjectGrid;
        Vector2 anchorPosition = parent.GetAnchorPosition(this);
        velocity = (anchorPosition - position) * 8;
        base.Update(gameTime);
    }
}
