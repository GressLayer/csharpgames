﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

class RowSelectGameObject : SpriteGameObject
{
    protected int selectedRow;
    protected JewelGrid grid;

    public RowSelectGameObject(JewelGrid grid, Texture2D selectorFrame, int layer = 0)
        : base(selectorFrame, layer)
    {
        selectedRow = 0;
        this.grid = grid;
    }

    public override void HandleInput(InputHelper inputHelper)
    {
        if (inputHelper.KeyPressed(Keys.Up))
        {
            selectedRow--;
        }
        else if (inputHelper.KeyPressed(Keys.Down))
        {
            selectedRow++;
        }
        selectedRow = (int)MathHelper.Clamp(selectedRow, 0, grid.Rows - 1);
        position = new Vector2(-10, grid.CellHeight * selectedRow - 10);

        if (inputHelper.KeyPressed(Keys.Left))
        {
            grid.ShiftRowLeft(selectedRow);
        }
        else if (inputHelper.KeyPressed(Keys.Right))
        {
            grid.ShiftRowRight(selectedRow);
        }
    }
}