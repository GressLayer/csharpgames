﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

class SpriteGameObject : GameObject
{
    protected Texture2D sprite;

    public SpriteGameObject(Texture2D spr, int layer = 0)
        : base(layer)
    {
        sprite = spr;
    }

    public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
        if (visible)
        {
            spriteBatch.Draw(sprite, GlobalPosition, Color.White);
        }
    }
}

