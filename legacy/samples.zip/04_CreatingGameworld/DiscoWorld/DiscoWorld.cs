using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;

class DiscoWorld : Game
{
    GraphicsDeviceManager graphics;
    SpriteBatch spriteBatch;
    Color background;

    [STAThread]
    static void Main()
    {
        DiscoWorld game = new DiscoWorld();
        game.Run();
    }

    public DiscoWorld()
    {
        Content.RootDirectory = "Content";
        graphics = new GraphicsDeviceManager(this);
    }

    protected override void LoadContent()
    {
        spriteBatch = new SpriteBatch(GraphicsDevice);
    }

    protected override void Update(GameTime gameTime)
    {
        int red = gameTime.TotalGameTime.Milliseconds;
        background = new Color(red, 0, 0);
    }

    protected override void Draw(GameTime gameTime)
    {
        GraphicsDevice.Clear(background);
    }
}