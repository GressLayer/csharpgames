﻿using Microsoft.Xna.Framework;

class JewelCart : SpriteGameObject
{
    protected float push;
    protected float minXPos;

    public JewelCart(int layer = 0, string id = "")
        : base("spr_jewelcart", layer, id)
    {
        velocity.X = 6;
        push = 50;
    }

    public override void Update(GameTime gameTime)
    {
        push = MathHelper.Max(push - 0.00001f, 1);
        base.Update(gameTime);
    }

    public override void Reset()
    {
        base.Reset();
        position.X = minXPos;
        velocity.X = 6;
    }

    public void Push()
    {
        position.X = MathHelper.Max(position.X - push, minXPos);
    }

    public float MinXPos
    {
        get { return minXPos; }
        set { minXPos = value; }
    }
}