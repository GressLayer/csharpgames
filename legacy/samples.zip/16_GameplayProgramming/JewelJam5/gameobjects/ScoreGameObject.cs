﻿using Microsoft.Xna.Framework;

class ScoreGameObject : TextGameObject
{
    protected int score;

    public ScoreGameObject(int layer = 0, string id = "")
        : base("JewelJamFont", layer, id)
    {
    }

    public override void Update(GameTime gameTime)
    {
        text = score.ToString();
        origin = TextSize;
    }

    public override void Reset()
    {
        base.Reset();
        score = 0;
    }

    public int Score
    {
        get { return score; }
        set { score = value; }
    }
}