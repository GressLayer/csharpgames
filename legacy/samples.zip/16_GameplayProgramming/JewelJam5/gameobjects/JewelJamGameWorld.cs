﻿using Microsoft.Xna.Framework;

class JewelJamGameWorld : GameObjectList
{
    public JewelJamGameWorld()
    {
        Add(new SpriteGameObject("spr_background"));

        SpriteGameObject scoreFrame = new SpriteGameObject("spr_scoreframe", 1);
        scoreFrame.Position = new Vector2(20, 20);
        Add(scoreFrame);

        ScoreGameObject score = new ScoreGameObject(2, "score");
        score.Position = new Vector2(270, 80);
        Add(score);

        JewelCart jewelCart = new JewelCart(1, "jewelcart");
        jewelCart.Position = new Vector2(410, 230);
        jewelCart.MinXPos = 410;
        Add(jewelCart);

        GameObjectList playingField = new GameObjectList(1, "playingfield");
        playingField.Position = new Vector2(85, 150);
        Add(playingField);

        JewelGrid grid = new JewelGrid(10, 5, 0, "grid");
        playingField.Add(grid);

        playingField.Add(new RowSelectGameObject(1));
    }
}