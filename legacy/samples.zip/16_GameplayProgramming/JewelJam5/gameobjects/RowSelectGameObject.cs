﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

class RowSelectGameObject : SpriteGameObject
{
    protected int selectedRow;

    public RowSelectGameObject(int layer = 0, string id = "")
        : base("spr_selector_frame", layer, id)
    {
        selectedRow = 0;
    }

    public override void HandleInput(InputHelper inputHelper)
    {
        JewelGrid grid = GameWorld.Find("grid") as JewelGrid;

        if (inputHelper.KeyPressed(Keys.Up))
        {
            selectedRow--;
        }
        else if (inputHelper.KeyPressed(Keys.Down))
        {
            selectedRow++;
        }
        selectedRow = (int)MathHelper.Clamp(selectedRow, 0, grid.Rows - 1);
        position = new Vector2(-10, grid.CellHeight * selectedRow - 10);

        if (inputHelper.KeyPressed(Keys.Left))
        {
            grid.ShiftRowLeft(selectedRow);
        }
        else if (inputHelper.KeyPressed(Keys.Right))
        {
            grid.ShiftRowRight(selectedRow);
        }
    }
}