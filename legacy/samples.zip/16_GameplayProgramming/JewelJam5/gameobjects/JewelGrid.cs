﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

class JewelGrid : GameObjectGrid
{
    public JewelGrid(int rows, int columns, int layer = 0, string id = "")
        : base(rows, columns, layer, id)
    {
        cellWidth = 85;
        cellHeight = 85;
        Reset();
    }

    public override void HandleInput(InputHelper inputHelper)
    {
        if (!inputHelper.KeyPressed(Keys.Space))
        {
            return;
        }
        int middleCol = Columns / 2;
        int nrCombis = 0;
        int i = 0;
        ScoreGameObject score = GameWorld.Find("score") as ScoreGameObject;
        while (i < Rows - 2)
        {
            if (IsValidCombination((Jewel)grid[middleCol, i], (Jewel)grid[middleCol, i + 1],
                (Jewel)grid[middleCol, i + 2]))
            {
                ReplaceJewel(middleCol, i, -cellHeight);
                ReplaceJewel(middleCol, i + 1, -cellHeight * 2);
                ReplaceJewel(middleCol, i + 2, -cellHeight * 3);

                score.Score += 10;

                JewelCart jewelCart = GameWorld.Find("jewelcart") as JewelCart;
                jewelCart.Push();

                nrCombis++;
                i = 0;
            }
            else
            {
                i++;
            }
        }
    }

    public bool IsValidCombination(Jewel a, Jewel b, Jewel c)
    {
        int curra = a.Variation;
        int currb = b.Variation;
        int currc = c.Variation;
        int divider = 9;
        for (int i = 0; i < 3; i++)
        {
            if ((curra / divider + currb / divider + currc / divider) % 3 != 0)
            {
                return false;
            }
            curra %= divider;
            currb %= divider;
            currc %= divider;
            divider /= 3;
        }
        return true;
    }

    public void ReplaceJewel(int x, int y, int newYPosition)
    {
        Clear(x, y);
        Jewel s = new Jewel();
        Add(s);
        s.Position = new Vector2(x * cellWidth, newYPosition);
    }

    public void ShiftRowRight(int selectedRow)
    {
        GameObject lastObj = grid[Columns - 1, selectedRow];
        for (int x = Columns - 1; x > 0; x--)
        {
            grid[x, selectedRow] = grid[x - 1, selectedRow];
        }
        grid[0, selectedRow] = lastObj;
        lastObj.Position = new Vector2(-cellWidth, selectedRow * cellHeight);
    }

    public void ShiftRowLeft(int selectedRow)
    {
        GameObject firstObj = grid[0, selectedRow];
        for (int x = 0; x < Columns - 1; x++)
        {
            grid[x, selectedRow] = grid[x + 1, selectedRow];
        }
        grid[Columns - 1, selectedRow] = firstObj;
        firstObj.Position = new Vector2(Columns * cellWidth, selectedRow * cellHeight);
    }

    public override void Reset()
    {
        ClearAll();
        for (int i = 0; i < Rows * Columns; i++)
        {
            Add(new Jewel());
        }
    }
}