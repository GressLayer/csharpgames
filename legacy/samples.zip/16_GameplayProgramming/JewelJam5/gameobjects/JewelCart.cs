﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

class JewelCart : SpriteGameObject
{
    protected float push;
    protected float minXPos;

    public JewelCart(int layer = 0, string id = "")
        : base("spr_jewelcart", layer, id)
    {
        velocity.X = 6;
        push = 50;
    }

    public void Push()
    {
        position.X = MathHelper.Max(position.X - push, minXPos);
    }

    public float MinXPos
    {
        get { return minXPos; }
        set { minXPos = value; }
    }
}

