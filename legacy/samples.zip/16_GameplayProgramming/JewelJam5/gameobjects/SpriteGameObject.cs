﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

class SpriteGameObject : GameObject
{
    protected Texture2D sprite;

    public SpriteGameObject(string assetName, int layer = 0, string id = "")
        : base(layer, id)
    {
        sprite = JewelJam.AssetManager.GetSprite(assetName);
    }

    public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
        if (visible)
        {
            spriteBatch.Draw(sprite, GlobalPosition, Color.White);
        }
    }

    public Texture2D Sprite
    {
        get { return sprite; }
    }

    public Vector2 Center
    {
        get { return new Vector2(sprite.Width, sprite.Height) / 2; }
    }
}