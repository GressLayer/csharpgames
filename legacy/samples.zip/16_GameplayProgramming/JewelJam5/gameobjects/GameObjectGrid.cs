﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

class GameObjectGrid : GameObject
{
    protected GameObject[,] grid;
    protected int cellWidth, cellHeight;

    public GameObjectGrid(int rows, int columns, int layer = 0, string id = "")
        : base(layer, id)
    {
        grid = new GameObject[columns, rows];
        for (int x = 0; x < columns; x++)
        {
            for (int y = 0; y < rows; y++)
            {
                grid[x, y] = null;
            }
        }
    }

    public void Add(GameObject obj)
    {
        for (int x = 0; x < Columns; x++)
        {
            for (int y = 0; y < Rows; y++)
            {
                if (grid[x, y] == null)
                {
                    grid[x, y] = obj;
                    obj.Parent = this;
                    obj.Position = new Vector2(x * cellWidth, y * cellHeight);
                    return;
                }
            }
        }
    }

    public void Clear(int x, int y)
    {
        for (int r = y; r > 0; r--)
        {
            grid[x, r] = grid[x, r - 1];
        }
        grid[x, 0] = null;
    }

    public void ClearAll()
    {
        for (int x = 0; x < Columns; x++)
        {
            for (int y = 0; y < Rows; y++)
            {
                grid[x, y] = null;
            }
        }
    }

    public Vector2 GetAnchorPosition(GameObject s)
    {
        for (int x = 0; x < Columns; x++)
        {
            for (int y = 0; y < Rows; y++)
            {
                if (grid[x, y] == s)
                {
                    return new Vector2(x * cellHeight, y * cellHeight);
                }
            }
        }
        return Vector2.Zero;
    }

    public int Rows
    {
        get { return grid.GetLength(1); }
    }

    public int Columns
    {
        get { return grid.GetLength(0); }
    }

    public int CellHeight
    {
        get { return cellHeight; }
    }

    public int CellWidth
    {
        get { return cellWidth; }
    }

    public override void HandleInput(InputHelper inputHelper)
    {
        foreach (GameObject obj in grid)
        {
            obj.HandleInput(inputHelper);
        }
    }

    public override void Update(GameTime gameTime)
    {
        foreach (GameObject obj in grid)
        {
            obj.Update(gameTime);
        }
    }

    public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
        foreach (GameObject obj in grid)
        {
            obj.Draw(gameTime, spriteBatch);
        }
    }

    public override void Reset()
    {
        foreach (GameObject obj in grid)
        {
            obj.Reset();
        }
    }
}