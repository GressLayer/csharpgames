﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

class TextGameObject : GameObject
{
    protected SpriteFont spriteFont;
    protected Color color;
    protected Vector2 origin;
    protected string text;

    public TextGameObject(string assetname, int layer = 0, string id = "")
        : base(layer, id)
    {
        spriteFont = JewelJam.AssetManager.Content.Load<SpriteFont>(assetname);
        color = Color.White;
        origin = Vector2.Zero;
        text = "";
    }

    public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
        if (visible)
        {
            spriteBatch.DrawString(spriteFont, text, GlobalPosition, color, 0f, origin, 1, SpriteEffects.None, 0);
        }
    }

    public override void Reset()
    {
        base.Reset();
        color = Color.White;
    }

    public Color Color
    {
        get { return color; }
        set { color = value; }
    }

    public string Text
    {
        get { return text; }
        set { text = value; }
    }

    public Vector2 TextSize
    {
        get { return spriteFont.MeasureString(text); }
    }

    public Vector2 Origin
    {
        get { return origin; }
        set { origin = value; }
    }
}