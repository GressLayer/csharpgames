using Microsoft.Xna.Framework;
using System;

class AnimatedCharacter : GameEnvironment
{
    [STAThread]
    static void Main()
    {
        AnimatedCharacter game = new AnimatedCharacter();
        game.Run();
    }

    public AnimatedCharacter()
    {
        Content.RootDirectory = "Content";
        IsMouseVisible = true;
    }

    protected override void LoadContent()
    {
        base.LoadContent();
        screen = new Point(800, 600);
        windowSize = new Point(1024, 768);
        FullScreen = false;

        gameStateManager.AddGameState("animationState", new AnimationState());
        gameStateManager.SwitchTo("animationState");
    }
}