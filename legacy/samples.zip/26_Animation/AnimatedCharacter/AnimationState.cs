﻿using Microsoft.Xna.Framework;

class AnimationState : GameObjectList
{
    public AnimationState()
    {
        Player player = new Player();
        player.Position = new Vector2(50, 600);
        this.Add(player);
    }
}