using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

class Player : AnimatedGameObject
{
    public Player() : base(0, "player")
    {
        LoadAnimation("Sprites/Player/spr_idle", "idle", true);
        LoadAnimation("Sprites/Player/spr_run@13", "run", true);
    }

    public override void HandleInput(InputHelper inputHelper)
    {
        velocity.X = 0.0f;
        if (inputHelper.IsKeyDown(Keys.Left))
        {
            velocity.X = -400;
        }
        else if (inputHelper.IsKeyDown(Keys.Right))
        {
            velocity.X = 400;
        } 
    }

    public override void Update(GameTime gameTime)
    {
        if (velocity.X == 0)
        {
            PlayAnimation("idle");
        }
        else
        {
            PlayAnimation("run");
        }
        Mirror = velocity.X < 0;
        base.Update(gameTime);
    }
}