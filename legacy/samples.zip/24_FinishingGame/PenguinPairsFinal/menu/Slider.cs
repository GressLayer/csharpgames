﻿using Microsoft.Xna.Framework;

class Slider : GameObjectList
{
    protected SpriteGameObject back, front;
    protected bool dragging;
    protected int leftMargin, rightMargin;

    public Slider(string sliderBack, string sliderFront, int layer = 0, string id = "")
        : base(layer, id)
    {
        back = new SpriteGameObject(sliderBack, 0);
        Add(back);

        front = new SpriteGameObject(sliderFront, 1);
        front.Position = new Vector2(0, 8);
        Add(front);

        leftMargin = 5;
        rightMargin = 7;

        dragging = false;
    }

    public override void HandleInput(InputHelper inputHelper)
    {
        base.HandleInput(inputHelper);
        if (!inputHelper.MouseLeftButtonDown())
        {
            dragging = false;
            return;
        }
        if (back.BoundingBox.Contains(inputHelper.MousePosition) || dragging)
        {
            float newXPos = MathHelper.Clamp(inputHelper.MousePosition.X - back.GlobalPosition.X - front.Width / 2, 
                back.Position.X + leftMargin, back.Position.X + back.Width - front.Width - rightMargin);
            front.Position = new Vector2(newXPos, front.Position.Y);
            dragging = true;
        }
    }

    public float Value
    {
        get
        {
            return (front.Position.X - back.Position.X - leftMargin) / (back.Width - leftMargin - rightMargin - front.Width);
        }
        set
        {
            float newXPos = value * (back.Width - front.Width - leftMargin - rightMargin) + back.Position.X + leftMargin;
            front.Position = new Vector2(newXPos, front.Position.Y);
        }
    }
}
