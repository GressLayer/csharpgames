using Microsoft.Xna.Framework;
using System;

class PenguinPairs : GameEnvironment
{
    [STAThread]
    static void Main()
    {
        PenguinPairs game = new PenguinPairs();
        game.Run();
    }

    public PenguinPairs()
    {
        Content.RootDirectory = "Content";
        IsMouseVisible = true;
        GameSettingsManager.SetValue("hints", "on");
    }    

    protected override void LoadContent()
    {
        base.LoadContent();
        screen = new Point(1200, 900);
        windowSize = new Point(1024, 768);
        FullScreen = false;
        
        // add the game states
        gameStateManager.AddGameState("playingState", new PlayingState(Content));
        gameStateManager.AddGameState("titleMenu", new TitleMenuState());
        gameStateManager.AddGameState("optionsMenu", new OptionsMenuState());
        gameStateManager.AddGameState("levelMenu", new LevelMenuState());
        gameStateManager.AddGameState("helpState", new HelpState());
        gameStateManager.AddGameState("levelFinishedState", new LevelFinishedState()); 
        gameStateManager.SwitchTo("titleMenu");

        // play background music
        AssetManager.PlayMusic("Sounds/snd_music");
    }
}