﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

class PairList : SpriteGameObject
{
    protected int [] pairs;
    protected SpriteGameObject pairSprite;

    public PairList(int nrPairs, int layer = 0, string id = "")
        : base("Sprites/spr_frame_goal",layer, id)
    {
        pairSprite = new SpriteGameObject("Sprites/spr_penguin_pairs@8");
        pairSprite.Parent = this;
        pairs = new int[nrPairs];
        for (int i = 0; i < pairs.Length; i++)
        {
            pairs[i] = 7;
        }
    }

    public void AddPair(int index)
    {
        int i = 0;
        while (i < pairs.Length && pairs[i] != 7)
        {
            i++;
        }
        if (i < pairs.Length)
        {
            pairs[i] = index;
        }
    }

    public bool Completed
    {
        get
        {
            for (int i = 0; i < pairs.Length; i++)
            {
                if (pairs[i] == 7)
                {
                    return false;
                }
            }
            return true;
        }
    }

    public override void Reset()
    {
        base.Reset();
        for (int i = 0; i < pairs.Length; i++)
        {
            pairs[i] = 7;
        }
    }

    public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
    {
        base.Draw(gameTime, spriteBatch);
        if (!visible)
        {
            return;
        }
        for (int i = 0; i < pairs.Length; i++)
        {
            pairSprite.Position = new Vector2(110 + i * sprite.Height, 8);
            pairSprite.Sprite.SheetIndex = pairs[i];
            pairSprite.Draw(gameTime, spriteBatch);
        }
    }
}

