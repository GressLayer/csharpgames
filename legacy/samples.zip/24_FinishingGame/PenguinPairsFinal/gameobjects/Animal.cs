﻿using Microsoft.Xna.Framework;
using System;

class Animal : SpriteGameObject
{
    protected Vector2 initialPosition;
    protected bool initialEmptyBox;
    protected bool boxed;

    public Animal(string assetname, int layer = 0, string id = "", char color = 'r')
        : base(assetname, layer, id, 8)
    {
        boxed = char.IsUpper(color);
        initialEmptyBox = boxed && char.ToLower(color) == 'x';
        string animals = "brgyopmx";
        sprite.SheetIndex = animals.IndexOf(char.ToLower(color));
    }

    public override void Reset()
    {
        base.Reset();
        position = initialPosition;
        velocity = Vector2.Zero;
        if (initialEmptyBox)
        {
            sprite.SheetIndex = 7;
        }
    }

    public override void HandleInput(InputHelper inputHelper)
    {
        if (!visible || boxed || velocity != Vector2.Zero ||
            !inputHelper.MouseLeftButtonPressed() ||
            !BoundingBox.Contains((int)inputHelper.MousePosition.X, (int)inputHelper.MousePosition.Y))
        {
            return;
        }
        AnimalSelector selector = GameWorld.Find("animalselector") as AnimalSelector;
        selector.Position = position;
        selector.Visible = true;
        selector.SelectedAnimal = this;
    }

    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime);
        if (!visible || velocity == Vector2.Zero)
        {
            return;
        }

        Point target = GetCurrentBlock();
        
        if (GetTileType(target) == TileType.Background) // we fall off the playing field
        {
            visible = false;
            velocity = Vector2.Zero;
            GameEnvironment.AssetManager.PlaySound("Sounds/snd_lost");
            return;
        }
        else if (GetTileType(target) == TileType.Wall) // we ran into a wall
        {
            StopMoving();
            return;
        }

        // check if there is a shark
        Level level = Root as Level;
        GameObject s = level.FindSharkAtPosition(target);
        if (s != null && s.Visible)
        {
            s.Visible = false;
            visible = false;
            StopMoving();
            GameEnvironment.AssetManager.PlaySound("Sounds/snd_eat");
        }

        // check if there is a penguin
        Animal j = level.FindAnimalAtPosition(target);
        if (j == null || !j.Visible)
        {
            return;
        }
        if (j.IsEmptyBox())
        {
            visible = false;
            j.sprite.SheetIndex = sprite.SheetIndex; // move the penguin inside the box
        }
        else if ((j.sprite.SheetIndex == sprite.SheetIndex || IsMultiColoredPenguin() || j.IsMultiColoredPenguin()) && !j.IsSeal())
        {
            // match!
            j.Visible = false;
            visible = false;
            PairList pairlist = GameWorld.Find("pairList") as PairList;
            pairlist.AddPair(sprite.SheetIndex);
            if (pairlist.Completed)
            {
                GameEnvironment.AssetManager.PlaySound("Sounds/snd_won");
            }
            else
            {
                GameEnvironment.AssetManager.PlaySound("Sounds/snd_pair");
            }
        }
        else
        {
            StopMoving();
        }
    }

    public Point GetCurrentBlock()
    {
        GameObjectGrid tilefield = GameWorld.Find("tilefield") as GameObjectGrid;
        Point p = new Point((int)Math.Floor(position.X / tilefield.CellWidth), (int)Math.Floor(position.Y / tilefield.CellHeight));
        if (velocity.X > 0)
        {
            p.X++;
        }
        if (velocity.Y > 0)
        {
            p.Y++;
        }
        return p;
    }

    public void StopMoving()
    {
        GameObjectGrid tilefield = GameWorld.Find("tilefield") as GameObjectGrid;
        // stop and set our position to the block we just moved out from
        velocity.Normalize();
        Vector2 oldBlock = new Vector2(GetCurrentBlock().X, GetCurrentBlock().Y) - velocity;
        position = oldBlock * new Vector2(tilefield.CellWidth, tilefield.CellHeight);
        velocity = Vector2.Zero;
    }

    public TileType GetTileType(Point p)
    {
        GameObjectGrid tilefield = GameWorld.Find("tilefield") as GameObjectGrid;
        if (IsOutsideField(p))
        {
            return TileType.Background;
        }
        Tile t = tilefield.Objects[p.X, p.Y] as Tile;
        return t.TileType;
    }

    public bool IsOutsideField(Point p)
    {
         GameObjectGrid tilefield = GameWorld.Find("tilefield") as GameObjectGrid;
         return (p.X < 0 || p.X >= tilefield.Columns || p.Y < 0 || p.Y >= tilefield.Rows);
    }

    public bool IsSeal()
    {
        return sprite.SheetIndex == 7 && !boxed;
    }

    public bool IsMultiColoredPenguin()
    {
        return sprite.SheetIndex == 6 && !boxed;
    }

    public bool IsEmptyBox()
    {
        return sprite.SheetIndex == 7 && boxed;
    }

    public Vector2 InitialPosition
    {
        set { initialPosition = value; }
    }
}

