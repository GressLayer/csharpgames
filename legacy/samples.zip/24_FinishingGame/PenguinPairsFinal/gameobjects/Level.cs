﻿using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;

class Level : GameObjectList
{
    protected List<Animal> animals;
    protected List<SpriteGameObject> sharks;
    protected bool locked, solved, firstMoveMade;

    protected Button hintButton, retryButton, quitButton;

    public Level(int levelIndex, StreamReader reader)
    {
        animals = new List<Animal>();
        sharks = new List<SpriteGameObject>();
        locked = true;
        solved = false;

        // add a background
        SpriteGameObject background = new SpriteGameObject("Sprites/spr_background_level", 0, "background");
        Add(background);

        // read the level title, comment, nr of required pairs
        string levelTitle = reader.ReadLine();
        string levelHelp = reader.ReadLine();
        int nrPairs = int.Parse(reader.ReadLine());

        // read the width and height of the level
        string[] stringList = reader.ReadLine().Split();
        int width = int.Parse(stringList[0]);
        int height = int.Parse(stringList[1]);

        // create the playingfield object
        GameObjectList playingField = new GameObjectList(1, "playingField");
        playingField.Position = new Vector2((1200 - width * 73) / 2, 100);
        Add(playingField);

        // read the hint information
        stringList = reader.ReadLine().Split();
        int hintX = int.Parse(stringList[0]) - 1;
        int hintY = int.Parse(stringList[1]) - 1;
        int hintDirection = int.Parse(stringList[2]);
        SpriteGameObject hint = new SpriteGameObject("Sprites/spr_arrow_hint@4", 2, "hint", hintDirection);
        hint.Position = new Vector2(hintX, hintY) * new Vector2(73, 72);
        playingField.Add(hint);

        // attach a visibility timer to the hint arrow
        VisibilityTimer hintVisible = new VisibilityTimer(hint, 0, "hintVisible");
        playingField.Add(hintVisible);

        // read the grid
        GameObjectGrid tileField = new GameObjectGrid(height, width, 1, "tilefield");
        tileField.CellHeight = 72;
        tileField.CellWidth = 73;
        for (int row = 0; row < height; row++)
        {
            string currRow = reader.ReadLine();
            for (int col = 0; col < currRow.Length; col++)
            {
                Tile t;
                
                switch (currRow[col])
                {
                    case '.' :      t = new Tile("Sprites/spr_field@2", 0, "", (row+col) % 2);
                                    tileField.Add(t, col, row);
                                    break;
                    case ' ':       t = new Tile("Sprites/spr_wall");
                                    t.TileType = TileType.Background;
                                    tileField.Add(t, col, row);
                                    break;
                    case 'r':
                    case 'b':
                    case 'g':
                    case 'o':
                    case 'p':
                    case 'y':
                    case 'm':
                    case 'x':
                    case 'R':
                    case 'B':
                    case 'G':
                    case 'O':
                    case 'P':
                    case 'Y':
                    case 'M':
                    case 'X':       t = new Tile("Sprites/spr_field@2", 0, "", (row + col) % 2);
                                    tileField.Add(t, col, row);
                                    string assetName = "Sprites/spr_penguin@8";
                                    if (char.IsUpper(currRow[col]))
                                        assetName = "Sprites/spr_penguin_boxed@8";
                                    Animal j = new Animal(assetName, 2, "", currRow[col]);
                                    j.Position = t.Position;
                                    j.InitialPosition = t.Position;
                                    playingField.Add(j);
                                    animals.Add(j);
                                    break;
                    case '@': t = new Tile("Sprites/spr_field@2", 0, "", (row + col) % 2);
                                    tileField.Add(t, col, row);
                                    SpriteGameObject s = new SpriteGameObject("Sprites/spr_shark", 2, "");
                                    s.Position = t.Position;
                                    playingField.Add(s);
                                    sharks.Add(s);
                                    break;
                    default  :      t = new Tile("Sprites/spr_wall");
                                    tileField.Add(t, col, row);
                                    t.TileType = TileType.Wall;
                                    break;
                }
                
            }
        }
        playingField.Add(tileField);

        // number of meetings
        PairList pairList = new PairList(nrPairs, 1, "pairList");
        pairList.Position = new Vector2(20, 15);
        Add(pairList);

        // add the penguin selector object
        AnimalSelector selector = new AnimalSelector(2, "animalselector");
        selector.Visible = false;
        playingField.Add(selector);

        // add a hint/retry button
        hintButton = new Button("Sprites/spr_button_hint", 1, "hintButton");
        hintButton.Position = new Vector2(916,20);
        Add(hintButton);
        firstMoveMade = false;

        retryButton = new Button("Sprites/spr_button_retry", 1, "retryButton");
        retryButton.Position = new Vector2(916, 20);
        retryButton.Visible = false;
        Add(retryButton);

        // add a quit button
        quitButton = new Button("Sprites/spr_button_quit", 1);
        quitButton.Position = new Vector2(1058, 20);
        Add(quitButton);

        // add the help field with the help text
        SpriteGameObject helpField = new SpriteGameObject("Sprites/spr_help", 1);
        helpField.Position = new Vector2((1200 - helpField.Width) / 2, 780);
        Add(helpField);
        TextGameObject helpText = new TextGameObject("Fonts/HelpFont", 2);
        helpText.Text = levelHelp.Replace('#', '\n');
        helpText.Color = Color.DarkBlue;
        helpText.Position = new Vector2((1200 - helpText.Size.X) / 2, (90 - helpText.Size.Y)/2 + 780);
        Add(helpText);        
    }

    public override void HandleInput(InputHelper inputHelper)
    {
        base.HandleInput(inputHelper);
        if (hintButton.Pressed && hintButton.Visible)
        {
            VisibilityTimer hintVisible = Find("hintVisible") as VisibilityTimer;
            hintVisible.StartVisible();
        }
        else if (retryButton.Pressed && retryButton.Visible)
        {
            Reset();
        }
    }

    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime);
        hintButton.Visible = GameEnvironment.GameSettingsManager.GetValue("hints") == "on" && !firstMoveMade;
        retryButton.Visible = !hintButton.Visible;
    }

    public override void Reset()
    {
        base.Reset();
        firstMoveMade = false;
    }

    public Animal FindAnimalAtPosition(Point pos)
    {
        foreach (Animal j in animals)
        {
            if (j.GetCurrentBlock() == pos && j.Velocity == Vector2.Zero)
            {
                return j;
            }
        }
        return null;
    }

    public GameObject FindSharkAtPosition(Point pos)
    {
        GameObjectGrid tilefield = Find("tilefield") as GameObjectGrid;
        Vector2 finalpos = new Vector2(pos.X * tilefield.CellWidth, pos.Y * tilefield.CellHeight);
        foreach (GameObject s in sharks)
        {
            if (s.Position == finalpos)
            {
                return s;
            }
        }
        return null;
    }

    public bool PlayerWon
    {
        get 
        {
            PairList pairlist = Find("pairList") as PairList; 
            return pairlist.Completed;
        }
    }

    public bool PlayerQuit
    {
        get { return quitButton.Pressed; }
    }

    public bool Locked
    {
        get { return locked; }
        set { locked = value; }
    }

    public bool Solved
    {
        get { return solved; }
        set { solved = value; }
    }

    public void FirstMoveMade()
    {
        firstMoveMade = true;
    }
}

