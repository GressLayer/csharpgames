﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Media;

class OptionsMenuState : GameObjectList
{
    protected Button backButton;
    protected Slider musicVolumeSlider;
    protected OnOffButton hintsOnButton;

    public OptionsMenuState()
    {
        // add a background
        SpriteGameObject background = new SpriteGameObject("Sprites/spr_background_options", 0, "background");
        Add(background);

        // add a hints on/off button
        TextGameObject hintsOnLabel = new TextGameObject("Fonts/MenuFont", 1);
        hintsOnLabel.Text = "Hints";
        hintsOnLabel.Position = new Vector2(150, 340);
        hintsOnLabel.Color = Color.DarkBlue;
        hintsOnButton = new OnOffButton("Sprites/spr_button_offon@2");
        hintsOnButton.Position = new Vector2(650, 340);
        hintsOnButton.On = GameEnvironment.GameSettingsManager.GetValue("hints") == "on";
        Add(hintsOnLabel);
        Add(hintsOnButton);

        // add a slider to control the background music volume
        TextGameObject musicVolumeLabel = new TextGameObject("Fonts/MenuFont", 1);
        musicVolumeLabel.Text = "Music volume";
        musicVolumeLabel.Color = Color.DarkBlue;
        musicVolumeLabel.Position = new Vector2(150, 480);
        Add(musicVolumeLabel);
        musicVolumeSlider = new Slider("Sprites/spr_slider_bar", "Sprites/spr_slider_button", 1);
        musicVolumeSlider.Position = new Vector2(650, 500);
        musicVolumeSlider.Value = MediaPlayer.Volume;
        Add(musicVolumeSlider);        

        // add a back but.ton
        backButton = new Button("Sprites/spr_button_back", 1);
        backButton.Position = new Vector2(415, 720);
        Add(backButton);
    }

    public override void HandleInput(InputHelper inputHelper)
    {
        base.HandleInput(inputHelper);
        if (backButton.Pressed)
        {
            GameEnvironment.GameStateManager.SwitchTo("titleMenu");
        }
    }


    public override void Update(GameTime gameTime)
    {
        base.Update(gameTime);
        MediaPlayer.Volume = musicVolumeSlider.Value;
        if (hintsOnButton.On)
        {
            GameEnvironment.GameSettingsManager.SetValue("hints", "on");
        }
        else
        {
            GameEnvironment.GameSettingsManager.SetValue("hints", "off");
        }
    }
}
